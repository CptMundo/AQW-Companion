/* Direct and user-expanded nested merge requirements. Same-origin public Wiki reads only. */
(() => {
 'use strict';
 const marker=/^Merge the following\s*:\s*$/i;
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 function parseRow(li,origin){
  if(li.querySelector('ul,ol'))return null;
  const links=[...li.querySelectorAll('a[href]')];if(links.length!==1)return null;
  const a=links[0],name=clean(a.textContent),line=clean(li.textContent);
  if(!name||name.length>350||!line.startsWith(name))return null;
  let u;try{u=new URL(a.href,origin)}catch{return null}
  if(u.origin!==origin||!/^\/[a-z0-9][a-z0-9-]*\/?$/.test(u.pathname)||u.search||u.hash)return null;
  const qty=line.slice(name.length).trim().match(/^[x×]\s*(\d{1,3}(?:,\d{3})+|\d+)$/i);
  if(!qty)return null;
  const target=Number(qty[1].replace(/,/g,''));if(!Number.isSafeInteger(target)||target<1||target>100000000)return null;
  return {name,slug:u.pathname.replace(/^\/|\/$/g,''),target};
 }
 function parse(content,origin){
  const groups=[];let incomplete=false;
  for(const el of content.querySelectorAll?.('li,p,div')||[]){
   const direct=clean([...el.childNodes].filter(n=>n.nodeType===3||n.nodeType===1&&!['UL','OL'].includes(n.tagName)).map(n=>n.textContent).join(' '));
   if(!marker.test(direct))continue;
   const lists=[...el.children].filter(n=>['UL','OL'].includes(n.tagName));
   if(!lists.length&&['UL','OL'].includes(el.nextElementSibling?.tagName))lists.push(el.nextElementSibling);
   if(lists.length!==1){incomplete=true;continue}
   const rows=[...lists[0].children];if(!rows.length||rows.length>50||rows.some(n=>n.tagName!=='LI')){incomplete=true;continue}
   const items=rows.map(li=>parseRow(li,origin));
   if(items.some(x=>!x)||new Set(items.map(x=>x.slug)).size!==items.length){incomplete=true;continue}
   groups.push(items);
   if(groups.length>8)return {groups:[],incomplete:true};
  }
  if(groups.reduce((n,g)=>n+g.length,0)>80)return {groups:[],incomplete:true};
  return {groups,incomplete};
 }
 function plan(group,states,matches,rootSlug,option=0){
  // Allocate the same actual inventory ID only once per alternative. Breadth-first
  // reserves all direct requirements before descending into missing sub-recipes.
  const remaining=new Map(),root=[],queue=[];let count=0,limited=false;
  function enqueue(items,parent,multiplier,ancestors,depth,prefix){
   if(items.length+count>80){limited=true;return false}
   items.forEach((m,i)=>{
    const target=m.target*multiplier,path=prefix+'.'+i;
    const node={...m,target,path,depth,ancestors,children:[],allocated:null,missing:null,stock:null,reason:''};
    parent.push(node);queue.push(node);count++;
   });return true
  }
  enqueue(group,root,1,[rootSlug],0,String(option));
  for(let i=0;i<queue.length;i++){
   const n=queue[i],m=matches.get(n.name);
   if(!Number.isSafeInteger(n.target)||n.target<1||n.target>100000000){n.reason='Quantity limit reached';continue}
   if(n.ancestors.includes(n.slug)){n.reason='Circular dependency';continue}
   if(!m||!['owned','not-found'].includes(m.state)){n.reason=m?.state==='ambiguous'?'Ambiguous item variant':'Inventory unavailable';continue}
   if(m.state==='owned'){
    if(typeof m.itemId!=='string'||!m.itemId||!Number.isSafeInteger(m.total)||m.total<0){n.reason='Inventory identity unavailable';continue}
    if(!remaining.has(m.itemId))remaining.set(m.itemId,m.total);
    n.stock=m.total;n.allocated=Math.min(n.target,remaining.get(m.itemId));
    remaining.set(m.itemId,remaining.get(m.itemId)-n.allocated);
   }else{n.stock=0;n.allocated=0}
   n.missing=n.target-n.allocated;
   const selected=states.get(n.path);
   if(n.missing&&selected?.groups?.[selected.choice]){
    if(n.depth>=4){n.reason='Maximum recipe depth reached';continue}
    if(!enqueue(selected.groups[selected.choice],n.children,n.missing,[...n.ancestors,n.slug],n.depth+1,n.path))n.reason='Recipe size limit reached';
   }
  }
  return {root,limited};
 }

 function sourceLink(a,origin){
  try{const u=new URL(a.getAttribute('href'),origin),name=clean(a.textContent).replace(/^['‘“]+|['’”]+$/g,'');if(u.origin!==origin||u.search||!/^\/[a-z0-9][a-z0-9-]{0,199}\/?$/.test(u.pathname)||!name||name.length>180||u.hash&&!/^#[a-zA-Z0-9_-]{1,80}$/.test(u.hash))return null;return {name,slug:u.pathname.replace(/^\/|\/$/g,''),hash:u.hash}}catch{return null}
 }
 function acquisitionKind(text){
 const t=clean(text).replace(/^Price:\s*/i,'').replace(/^N\/A\s*\(?\s*/i,'');
 if(/^(?:Notes?|Description|Sellback|Type|Used (?:in|to)|Required (?:for|to)|Also see)\b/i.test(t))return 'stop';
 if(/^Locations?\s*:/i.test(t))return 'locations';
 if(/^Dropped by\b/i.test(t))return 'drops';
 if(/^(?:Reward(?:ed)? from|Quest reward)\b/i.test(t)&&/\bquests?\b/i.test(t))return 'quests';
 if(/^(?:Purchased from|Bought from|Available from)\b/i.test(t))return 'shops';
 if(/^Merge the following\b/i.test(t))return 'stop';
 return null;
 }
 function acquisitionLines(content){
  const rows=[];let value='',links=[],listDepth=0;
  function flush(){const text=clean(value);if(text||links.length)rows.push({text,links,listDepth});value='';links=[]}
  function walk(node){
   if(node.nodeType===3){value+=node.textContent||'';return}
   if(node.nodeType!==1)return;
   const tag=node.tagName;if(['SCRIPT','STYLE','IMG','IFRAME'].includes(tag))return;
   if(node.matches?.('#breadcrumbs,.breadcrumbs,.breadcrumb,.page-tags,.page-rate-widget-box'))return;
   if(tag==='BR'||tag==='HR'){flush();return}
   if(tag==='A'){value+=node.textContent||'';links.push(node);return}
   const block=['P','DIV','LI','UL','OL','H1','H2','H3','H4','H5','TABLE','TR','TD'].includes(tag);if(block)flush();
   if(tag==='LI')listDepth++;
   for(const c of node.childNodes||[])walk(c);
   if(block)flush();if(tag==='LI')listDepth--;
  }
  for(const child of content.childNodes||[])walk(child);flush();return rows;
 }
 function parseAcquisitionLines(rows,origin){
  const out={locations:[],drops:[],quests:[],shops:[]};let active=null,notes=false;
  for(const row of rows){
   if(/^(?:Notes?|Description|Sellback|Type)\s*:/i.test(row.text)){active=null;if(/^Notes?\s*:/i.test(row.text))notes=true;continue}
   if(notes)continue;
   const kind=acquisitionKind(row.text);
   if(kind==='stop'){active=null;continue}
   if(kind)active=kind;else if(!row.listDepth){active=null;continue}
   if(!active)continue;
   for(const a of row.links){const item=sourceLink(a,origin);if(!item)continue;
    const bucket=active==='locations'&&(/\b(?:shop|merge)\b/i.test(item.name)||/(?:-merge|-shop)$/.test(item.slug))?'shops':active;
    if(!out[bucket].some(x=>x.slug===item.slug&&x.name===item.name&&x.hash===item.hash)&&out[bucket].length<40)out[bucket].push(item);
   }
  }
  return out;
 }
 // Read only native, explicitly labelled item fields. Never infer acquisition from Notes.
 function itemSummary(rows,origin,slug){
  const descriptions=[],locations=[],prices=[],methods=[],shopLinks=[];let active='',merge=false,priceFields=0,locationFields=0;
  const text=s=>clean(s);
  const unique=(a,key)=>[...new Map(a.map(x=>[key(x),x])).values()];
  const links=row=>unique((row.links||[]).map(a=>sourceLink(a,origin)).filter(Boolean),x=>x.slug+(x.hash||''));
  const addLocation=(value,row)=>{if(!value)return;const ls=links(row);locations.push({text:value,links:ls});for(const l of ls)if(/\b(?:shop|merge)\b/i.test(l.name)||/(?:-merge|-shop)$/.test(l.slug))shopLinks.push(l)};
  const addMethod=(label,row)=>{const ls=links(row);if(ls.length)methods.push({label,links:ls})};
  const price=(value,row)=>{
   const v=text(value);
   if(/^Merge the following\s*:/i.test(v)){merge=true;return}
   if(/^(?:N\/A\s*\(?\s*)?(?:Reward(?:ed)? from|Quest reward)\b/i.test(v)&&/\bquests?\b/i.test(v)){addMethod('Quest reward',row);return}
   if(/^(?:N\/A\s*\(?\s*)?Dropped by\b/i.test(v)){addMethod('Dropped by',row);return}
   if(/^(?:N\/A\s*\(?\s*)?(?:Purchased from|Bought from|Available from)\b/i.test(v)){addMethod('Shop',row);return}
   if(/^\d[\d,]*(?:\.\d+)?\s*(?:ACs?|Gold)(?:\s*\([^)]{1,60}\))?$/i.test(v))prices.push(v);
  };
  for(const row of rows){
   const t=text(row.text);if(/^Notes?\s*:/i.test(t))break;
   const m=t.match(/^(Locations?|Price|Description|Sellback|Rarity|Base Damage|Type|Level|Stack|Quantity)\s*:\s*(.*)$/i);
   if(m){
    active=m[1].toLowerCase();const v=m[2];
    if(active==='description'&&v&&!/^(?:no description|n\/a)[.!]?$/i.test(v))descriptions.push(v);
    else if(active.startsWith('location')){locationFields++;addLocation(v,row)}
    else if(active==='price'){priceFields++;price(v,row)}
    continue;
   }
   if(active.startsWith('location')&&row.listDepth>0)addLocation(t,row);
   else if(active==='price'&&(row.listDepth>0||/^Merge the following\s*:/i.test(t)))price(t,row);
   else if(!row.listDepth)active='';
  }
  if(new Set(descriptions).size>1||locationFields>1||priceFields>1)return null;
  const distinctPrices=[...new Set(prices)],shops=unique(shopLinks,x=>x.slug);
  if(slug==='blinding-light-of-destiny-axe'){
   methods.unshift({label:'Quest unlock',links:[{name:'The Blinding Light of Destiny',slug:'artix-s-quests',hash:''}]});
   methods.push({label:'Reward shop',links:[{name:'Blinding Light of Destiny (Shop)',slug:'blinding-light-of-destiny-shop',hash:''}]});
   if(merge)methods.push({label:'Merge shop',links:[{name:"Yulgar's Dual Wield Drop Off",slug:'yulgar-s-dual-wield-drop-off',hash:''}]});
   // This is a quest-unlocked 0 AC claim, not a paid price.
   distinctPrices.splice(0,distinctPrices.length,...distinctPrices.filter(v=>!/^0\s*ACs?$/i.test(v)));
  }else if(merge){
   const explicit=shops.filter(x=>/\bmerge\b|dual wield drop off/i.test(x.name)||/-merge$/.test(x.slug));
   const known=distinctPrices.length?explicit:shops;
   if(known.length)methods.push({label:known.length>1?'Merge shops':'Merge shop',links:known});
   else if(shops.length)methods.push({label:'Acquisition',links:shops});
   else methods.push({label:'Merge',links:[]});
  }
  return {description:descriptions[0]||'',locations,prices:distinctPrices,methods:unique(methods,x=>x.label+'|'+x.links.map(l=>l.slug+l.hash).join('|'))};
 }
 function parseSources(content,origin){
  if(content.childNodes)return parseAcquisitionLines(acquisitionLines(content),origin);
  const out={locations:[],drops:[],quests:[],shops:[]};
  function add(kind,a){const item=sourceLink(a,origin);if(item&&!out[kind].some(x=>x.slug===item.slug&&x.name===item.name&&x.hash===item.hash)&&out[kind].length<40)out[kind].push(item)}
  // Read only acquisition-labelled lines and their immediately attached list.
  // Stop at Sellback/Description/Notes. Never treat 'Used in' as a reward.
  for(const el of content.querySelectorAll('p,li,div,strong,b')){
   const direct=clean([...el.childNodes].filter(n=>n.nodeType===3||n.nodeType===1&&!['UL','OL','DIV','P'].includes(n.tagName)).map(n=>n.textContent).join(' '));
   if(!direct||direct.length>400||/^(Notes?|Description|Sellback|Used (?:in|to))\b/i.test(direct))continue;
   const kind=/^Locations?\s*:/i.test(direct)?'locations':/^(?:Price:\s*N\/A\s*\(?\s*)?Dropped by\b/i.test(direct)?'drops':/^(?:Price:\s*N\/A\s*\(?\s*)?Reward(?:ed)? from\b.*\bquests?\b/i.test(direct)?'quests':/^(?:Price:\s*N\/A\s*\(?\s*)?(?:Purchased from|Bought from|Available from)\b/i.test(direct)?'shops':null;
   if(!kind)continue;
   // Only explicit source links. A non-quest reward such as friendship is excluded.
   for(const a of el.querySelectorAll('a[href]'))add(kind,a);
   if(['UL','OL'].includes(el.nextElementSibling?.tagName)&&/:\s*$/.test(direct))for(const a of el.nextElementSibling.querySelectorAll('a[href]'))add(kind,a);
   if(['STRONG','B'].includes(el.tagName)&&/:\s*$/.test(direct)){
    for(let n=el.nextSibling,limit=0;n&&limit++<12;n=n.nextSibling){if(['BR','STRONG','B','P','DIV'].includes(n.nodeName))break;if(n.nodeName==='A')add(kind,n);else if(n.nodeType===1)for(const a of n.querySelectorAll('a[href]'))add(kind,a)}
   }
  }
  return out;
 }
 const knownSources={
  'moon-rock-fragments':{locations:[{name:'Luna Cove',slug:'luna-cove',join:'lunacove'}],drops:[{name:'Coral Merdraconian',slug:'coral-merdraconian'},{name:'Horde Lycan',slug:'horde-lycan'},{name:'Lunar Villager',slug:'lunar-villager'},{name:'Moonrock',slug:'moonrock'}],quests:[],shops:[]}
 };
 function reviewedSources(slug){return Object.hasOwn(knownSources,slug)?knownSources[slug]:null}
 function mergeSources(primary,reviewed){
  const result={};for(const kind of ['locations','drops','quests','shops']){const list=[...(reviewed?.[kind]||[])];for(const x of primary?.[kind]||[])if(!list.some(y=>y.slug===x.slug&&y.name===x.name&&(y.hash||'')===(x.hash||'')))list.push(x);result[kind]=list}
  return result;
 }
 function mapCommand(content){
  const text=String(content?.innerText||content?.textContent||'');
  const names=[...new Set([...text.matchAll(/\bMap Name\s*:\s*([a-z0-9-]{1,60})\b/gi)].map(m=>m[1].toLowerCase()))];
  const joins=[...new Set([...text.matchAll(/\/join\s+([a-z0-9-]{1,60})\b/gi)].map(m=>m[1].toLowerCase()))];
  return names.length===1&&joins.includes(names[0])?names[0]:null;
 }
 const verifiedMaps=Object.freeze({'luna-cove':'lunacove','shadowfall':'shadowfall','battleodium':'battleodium','yulgar-s-inn':'yulgar','titan-attack':'titanattack','mermaid-sushi':'mermaidsushi'});
 const mapCache=new Map(),mapPending=new Map();let mapRequests=0,mapQueue=Promise.resolve();
 async function verifyMap(origin,slug){
  if(mapCache.has(slug))return mapCache.get(slug);
  if(mapRequests>=10)throw Error('Map lookup limit reached; open the location page.');
  mapRequests++;
  const doc=await loadDocument(origin,slug),content=doc.querySelector('#page-content');
  const crumb=doc.querySelector('#breadcrumbs')||doc.querySelector('.breadcrumbs, #breadcrumb, .breadcrumb');
  if(!content||!doc.querySelector('#page-title')||![...(crumb?.querySelectorAll('a[href]')||[])].some(a=>sourceLink(a,origin)?.slug==='locations'))throw Error('Not a verified location page.');
  const join=mapCommand(content);if(!join)throw Error('Map command not verified.');
  mapCache.set(slug,join);return join;
 }
 function resolvedMap(origin,slug){
  if(Object.hasOwn(verifiedMaps,slug))return Promise.resolve(verifiedMaps[slug]);
  if(mapCache.has(slug))return Promise.resolve(mapCache.get(slug));
  if(mapPending.has(slug))return mapPending.get(slug);
  if(mapPending.size>=10)return Promise.resolve(null);
  const task=mapQueue.then(()=>verifyMap(origin,slug)).catch(()=>null);mapPending.set(slug,task);mapQueue=task.then(()=>{});return task;
 }
 function joinControl(line,x,origin){
  const known=x.join||(Object.hasOwn(verifiedMaps,x.slug)?verifiedMaps[x.slug]:null)||mapCache.get(x.slug);
  const copy=document.createElement('button');copy.type='button';copy.className='aqwc-copy-join';
  function ready(command){if(!command){copy.remove();return}copy.textContent='/join '+command;copy.title='Copy /join '+command;copy.disabled=false;copy.addEventListener('click',async e=>{if(!e.isTrusted)return;try{await navigator.clipboard.writeText('/join '+command);copy.textContent='Copied /join '+command}catch{copy.textContent='/join '+command+' (copy manually)'}})}
  if(known){line.append(copy);ready(known)}else{copy.disabled=true;copy.textContent='Verifying map…';line.append(copy);resolvedMap(origin,x.slug).then(ready)}
 }
 // Reviewed primary acquisition route. The Wiki axe page lists the unlocked
 // shop and an exchange recipe, but the shop's unlock quest is the original farm.
 function reviewedRoutes(parsed,slug){
  if(slug!=='blinding-light-of-destiny-axe')return parsed;
  const primary=[
   ['Bright Aura','bright-aura',125],['Brilliant Aura','brilliant-aura',75],
   ['Blinding Aura','blinding-aura',1],['Spirit Orb (Misc)','spirit-orb-misc',500],
   ['Loyal Spirit Orb','loyal-spirit-orb',250],['Ultimate Weapon Kit','ultimate-weapon-kit',1]
  ].map(([name,slug,target])=>({name,slug,target}));
  return {...parsed,groups:[primary,...parsed.groups.filter(g=>g.length===1&&g[0].slug==='dual-blinding-light-of-destiny')]};
 }
 function recipeLabel(group,index,rootSlug){
  if(rootSlug==='blinding-light-of-destiny-axe'){
   if(group.length===6&&group[0].slug==='bright-aura')return 'Original quest';
   if(group.length===1&&group[0].slug==='dual-blinding-light-of-destiny')return 'Exchange dual weapon';
  }

  if(rootSlug==='necrotic-sword-of-doom'||rootSlug==='necrotic-sword-of-doom-sword'){
   if(group.length===1&&group[0].slug==='dual-necrotic-swords-of-doom')return 'Exchange weapon';
   if(group.length===5)return 'Craft weapon';
  }
  return group.length===1?group[0].name:'Recipe '+(index+1);
 }
 function renderSources(container,sources,origin,slug,{partial=false}={}){
  if(!sources||!Object.values(sources).some(a=>a.length))return false;
  const box=document.createElement('div');box.className='aqwc-source-guide';const title=document.createElement('strong');title.textContent='Acquisition';box.append(title);
  for(const [kind,label] of [['locations','Locations'],['drops','Drops from'],['quests','Quest rewards'],['shops','Available from']]){
   const rows=sources[kind]||[];if(!rows.length)continue;
   const group=document.createElement('div'),heading=document.createElement('small');group.className='aqwc-source-group';heading.className='aqwc-source-label';heading.textContent=label;group.append(heading);const entries=document.createElement('div');entries.className='aqwc-source-entries';group.append(entries);
   for(const x of rows.slice(0,40)){
    const line=document.createElement('div');line.className='aqwc-source-line';const a=document.createElement('a');a.href=origin+'/'+x.slug+(x.hash||'');a.textContent=x.name;line.append(a);
    if(kind==='locations'&&!/\b(shop|merge shop)\b/i.test(x.name)){
     joinControl(line,x,origin);
    }
    entries.append(line);
   }
   box.append(group);
  }
  if(partial){const note=document.createElement('small');note.textContent='Partial source list';box.append(note)}
  const link=document.createElement('a');link.href=origin+'/'+slug;link.textContent='Material Wiki ↗';link.className='aqwc-source-page';box.append(link);container.append(box);return true;
 }
 async function loadDocument(origin,slug){
  if(origin!=='https://aqwwiki.wikidot.com'||! /^[a-z0-9][a-z0-9-]{0,199}$/.test(slug))throw Error('Unsupported Wiki link');
  const url=origin+'/'+slug,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
  try{
   const r=await fetch(url,{credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:controller.signal});
   if(!r.ok||r.url!==url||!String(r.headers.get('content-type')).includes('text/html'))throw Error('Wiki page unavailable');
   if(!r.body||Number(r.headers.get('content-length'))>1500000)throw Error('Wiki page too large');
   const reader=r.body.getReader(),decoder=new TextDecoder();let html='',size=0;
   try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>1500000){await reader.cancel();throw Error('Wiki page too large')}html+=decoder.decode(value,{stream:true})}html+=decoder.decode()}finally{reader.releaseLock()}
   const template=document.createElement('template');template.innerHTML=html;
   return template.content;
  }finally{clearTimeout(timer)}
 }
 // Keep successful artwork lookups; transient failures may be retried after a cooldown.
 function previewCacheRequest(cache,key,request,now=Date.now){
  const previous=cache.get(key);if(previous&&previous.retryAt>now())return previous.promise;
  const entry={retryAt:Infinity,promise:null};
  entry.promise=Promise.resolve().then(request).then(urls=>{if(!urls.length)entry.retryAt=now()+15000;return urls},()=>{entry.retryAt=now()+15000;return []});
  cache.set(key,entry);return entry.promise;
 }
 const monsterCache=new Map();let monsterRequests=0,monsterQueue=Promise.resolve();
 function monsterImages(doc,origin,slug){
  const crumb=doc.querySelector('#breadcrumbs')||doc.querySelector('.breadcrumbs, #breadcrumb, .breadcrumb'),content=doc.querySelector('#page-content');
  if(!content||![...(crumb?.querySelectorAll('a[href]')||[])].some(a=>sourceLink(a,origin)?.slug==='monsters'))return [];
  const all=[],after=[];
  // The Wiki generally puts event/type emblems before Location and the actual art after the drop lists.
  const headings=[...content.querySelectorAll('strong,b')].filter(el=>/^(?:Temporary Items Dropped|Items Dropped|Attacks|Abilities)\s*:/i.test(String(el.textContent||'').trim()));
  const last=headings[headings.length-1];
  for(const img of content.querySelectorAll('img[src]')){
   const src=img.getAttribute('src')||'';
   if(img.closest('li,.page-rate-widget-box,#breadcrumbs,.breadcrumbs')||/(?:^|\/)(?:(?:ac|legend|rare|seasonal|special|pseudo|member|free)(?:small|large)|(?:star|stars|icon|badge|logo|button|blank)[-_0-9]*)\.(?:png|gif|jpe?g|webp)(?:\?|$)/i.test(src))continue;
   try{const u=new URL(src,origin+'/'+slug);if(u.username||u.password||!/\.(png|jpe?g|webp|gif)$/i.test(u.pathname)||!(u.hostname==='aqwwiki.wikidot.com'||u.hostname.endsWith('.wdfiles.com')||u.hostname==='i.imgur.com'))continue;if(u.protocol==='http:')u.protocol='https:';if(u.protocol!=='https:')continue;
    const w=Number(img.getAttribute('width')),h=Number(img.getAttribute('height'));if((w>0&&w<90)||(h>0&&h<75))continue;
    all.push(u.href);if(last&&typeof last.compareDocumentPosition==='function'&&(last.compareDocumentPosition(img)&4))after.push(u.href);
   }catch{}
  }
  // On a confirmed monster page, prefer art below the last stats/drop heading.
  // If no positional evidence exists, accept only a unique image (never a random badge).
  const distinct=[...new Set(after)];if(distinct.length)return distinct.slice(0,4);
  const unique=[...new Set(all)];return unique.length===1?unique:[];
 }
 function monsterImage(doc,origin,slug){return monsterImages(doc,origin,slug)[0]||null}
 function monsterPreview(origin,slug){
  if(origin!=='https://aqwwiki.wikidot.com'||! /^[a-z0-9][a-z0-9-]{0,199}$/.test(slug))return Promise.resolve([]);
  return previewCacheRequest(monsterCache,slug,()=>{if(monsterRequests>=64)return [];monsterRequests++;const p=monsterQueue.then(()=>loadDocument(origin,slug)).then(doc=>monsterImages(doc,origin,slug));monsterQueue=p.then(()=>{},()=>{});return p});
 }
 const itemArtCache=new Map();let itemArtRequests=0,itemArtQueue=Promise.resolve();
 function itemImages(doc,origin,slug){
  const crumb=doc.querySelector('#breadcrumbs,.breadcrumbs,#breadcrumb,.breadcrumb'),content=doc.querySelector('#page-content');
  if(!content||![...(crumb?.querySelectorAll('a[href]')||[])].some(a=>sourceLink(a,origin)?.slug==='items'))return [];
  const headings=[...content.querySelectorAll('strong,b')].filter(el=>/^(?:Description|Rarity|Base Damage|Sellback|Notes?)\s*:/i.test(String(el.textContent||'').trim()));
  const last=headings[headings.length-1];if(!last)return [];
  const urls=[];for(const img of content.querySelectorAll('img[src]')){
   if(!(last.compareDocumentPosition(img)&4)||img.closest('li,table,.page-rate-widget-box'))continue;
   const src=img.getAttribute('src')||'';if(/(?:badge|icon|(?:ac|legend|rare|seasonal)(?:small|large))\.(?:png|gif|jpe?g)/i.test(src))continue;
   try{const u=new URL(src,origin+'/'+slug);if(u.protocol==='http:')u.protocol='https:';if(u.protocol!=='https:'||u.username||u.password||!/\.(png|gif|jpe?g|webp)$/i.test(u.pathname)||!(u.hostname==='aqwwiki.wikidot.com'||u.hostname.endsWith('.wdfiles.com')||u.hostname==='i.imgur.com'))continue;const w=Number(img.getAttribute('width')),h=Number(img.getAttribute('height'));if((w>0&&w<90)||(h>0&&h<75))continue;urls.push(u.href)}catch{}
  }return [...new Set(urls)].slice(0,4);
 }
 function itemPreview(origin,slug){if(origin!=='https://aqwwiki.wikidot.com'||! /^[a-z0-9][a-z0-9-]{0,199}$/.test(slug))return Promise.resolve([]);return previewCacheRequest(itemArtCache,slug,()=>{if(itemArtRequests>=48)return [];itemArtRequests++;const p=itemArtQueue.then(()=>loadDocument(origin,slug)).then(doc=>itemImages(doc,origin,slug));itemArtQueue=p.then(()=>{},()=>{});return p})}
 async function loadRecipe(origin,slug){
   const doc=await loadDocument(origin,slug),content=doc.querySelector('#page-content'),url=origin+'/'+slug;
   const body=String(content?.textContent||'');
   const crumb=doc.querySelector('#breadcrumbs')||doc.querySelector('.breadcrumbs, #breadcrumb, .breadcrumb');
   const links=[...(crumb?.querySelectorAll('a[href]')||[])];
   if(!content||!doc.querySelector('#page-title')||!/\bSellback\s*:/i.test(body)||!/\bDescription\s*:/i.test(body)||/\busually refers to\s*:/i.test(body)||links.length&&!links.some(a=>{try{return new URL(a.getAttribute('href'),url).pathname.replace(/^\/|\/$/g,'')==='items'}catch{return false}}))return {groups:[],incomplete:true};
   return {...parse(content,origin),sources:parseSources(content,origin)};
 }

 // Reviewed acquisition hints for popular goals. These are informational
 // previews only; nested allocation uses parsed recipes on explicit expansion.
 const shadowfallSource={name:'Shadowfall',slug:'shadowfall',join:'shadowfall'};
 const mergeHint=parts=>({merge:parts,locations:[shadowfallSource]});
 // Sources: /revenant-s-spellscroll, /conquest-wreath, /exalted-crown, /legion-revenant-s-quests, /dage-challenge, /ultra-dage.
 const legionHint=names=>({merge:[['Dage the Evil Insignia',1],['Legion Token',50]],quests:names.map(name=>({name,slug:'legion-revenant-s-quests'})),locations:[{name:'Dage Challenge',slug:'dage-challenge',join:'dage'},{name:'Ultra Dage',slug:'ultra-dage',join:'ultradage'}]});
 const compactHints={
  'revenant-s-spellscroll':legionHint(['Legion Fealty 1']),
  'conquest-wreath':legionHint(['Legion Fealty 2']),
  'exalted-crown':legionHint(['Legion Fealty 3','Legion Fealty 4']),
  'necrotic-sword-s-blade':mergeHint([['Energized Blade',1],['Void Aura',200],['Barium of Doom',1]]),
  'necrotic-sword-s-hilt':mergeHint([['Energized Hilt',1],['Bones from the Void Realm',1],['Void Aura',200]]),
  'necrotic-sword-s-aura':mergeHint([['Energized Aura',1],["Time Lord's Necronomicon",1],['Void Aura',300]]),
  'energized-blade':mergeHint([['Barium of Doom',1],['Unenhanced Doom Blade',1],['Void Aura',100]]),
  'energized-hilt':mergeHint([['Bones from the Void Realm',1],['Unenhanced Hilt',1],['Void Aura',100]]),
  'energized-aura':mergeHint([["Time Lord's Necronomicon",1],['Unenhanced Aura',1],['Void Aura',150]]),
  'barium-of-doom':mergeHint([['Barium',1],['Void Aura',50]]),
  'bones-from-the-void-realm':mergeHint([['Bone Dust',50],['Void Aura',50]]),
  'time-lord-s-necronomicon':mergeHint([['Chaorrupted Hourglass',10],['(Necro) Scroll of Dark Arts',1],['Void Aura',100]]),
  'void-aura':{quests:['Commanding Shadow Essences','Gathering Unstable Essences','Glimpse Into The Dark (Daily)','Retrieve Void Auras','The Encroaching Shadows (Daily)'].map(name=>({name,slug:'braeus-quests'})),locations:[{name:'Battleodium',slug:'battleodium',join:'battleodium'},shadowfallSource,{name:"Yulgar's Inn",slug:'yulgar-s-inn',join:'yulgar'}]},
  'doom-heart':{drops:[{name:'ULTRA Sepulchure'}],locations:[{name:'Sepulchure Battle',slug:'sepulchure-battle',join:'sepulchurebattle'}]}
 };
 function compactData(slug,recipe){
  const hint=Object.hasOwn(compactHints,slug)?compactHints[slug]:null;
  const sources=recipe?.sources?mergeSources(recipe.sources,reviewedSources(slug)):hint||reviewedSources(slug);
  const merge=recipe?.groups?.length===1?recipe.groups[0].map(x=>[x.name,x.target]):recipe?.groups?.length>1?null:hint?.merge;
  return {sources,merge,alternatives:recipe?.groups?.length>1?recipe.groups.length:0};
 }
 function acquisitionGroups(data){
 const s=data.sources||{},mergeShops=(s.shops||[]).filter(x=>/\bmerge\b/i.test(x.name)||/-merge$/.test(x.slug||''));
 const otherShops=(s.shops||[]).filter(x=>!mergeShops.includes(x));
 const groups=[
  {kind:'quest',title:'Quest rewards',description:'Complete these quests and claim the material as a reward.',items:s.quests||[]},
  {kind:'drop',title:'Monster drops',description:'Defeat these monsters to obtain the material as a drop.',items:s.drops||[]},
  {kind:'merge',title:'Merge recipe',description:'Exchange the required ingredients for this material.',items:data.merge?.map(([name,qty])=>({name:name+' ×'+qty}))|| (data.alternatives?[{name:data.alternatives+' alternative recipes — choose below'}]:[])},
  {kind:'merge',title:'Merge shops',description:'Listed merge shop locations. Check the shop for the required exchange.',items:mergeShops},
  {kind:'shop',title:'Shops',description:'Listed shop sources. Check the price and access requirements.',items:otherShops},
  {kind:'location',title:'Locations',description:'Travel to these listed maps to find the acquisition source.',items:(s.locations||[]).filter(x=>!/\b(?:shop|merge shop)\b/i.test(x.name))}
 ];
 return groups.filter(g=>g.items.length);
 }
 function renderAcquisitionGuide(container,slug,recipe,origin){
  const groups=acquisitionGroups(compactData(slug,recipe));if(!groups.length)return false;
  const guide=document.createElement('div');guide.className='aqwc-acquisition-guide';
  const title=document.createElement('strong');title.className='aqwc-acquisition-heading';title.textContent='How to obtain';guide.append(title);
  const grid=document.createElement('div');grid.className='aqwc-acquisition-grid';guide.append(grid);
  for(const g of groups){const card=document.createElement('section');card.className='aqwc-acquisition-card';card.dataset.kind=g.kind;
   const h=document.createElement('strong');h.textContent=g.title;const p=document.createElement('p');p.textContent=g.description;card.append(h,p);
   const list=document.createElement('ul');
   for(const x of g.items){const li=document.createElement('li'),el=document.createElement(x.slug?'a':'span');el.textContent=x.name;if(x.slug)el.href=origin+'/'+x.slug+(x.hash||'');li.append(el);
    if(g.kind==='location'&&x.slug)joinControl(li,x,origin);list.append(li)}
   card.append(list);grid.append(card);
  }
  const foot=document.createElement('div');foot.className='aqwc-acquisition-footer';const link=document.createElement('a');link.href=origin+'/'+slug;link.textContent='Material Wiki ↗';foot.append(link);
  if(recipe?.incomplete||!recipe?.sources||!groups.some(g=>g.kind!=='location')){const small=document.createElement('small');small.textContent='Some acquisition details may be missing. Verify on the Wiki.';foot.append(small)}
  guide.append(foot);container.append(guide);return true;
 }
 function compactSummary(row,slug,recipe,origin,{all=false}={}){
  const data=compactData(slug,recipe),s=data.sources;
  if(!s&&!data.merge&&!data.alternatives)return false;
  const block=document.createElement('div');block.className='aqwc-compact-sources';
  function line(label,items,kind){
   if(!items?.length)return;
   const line=document.createElement('div');line.className='aqwc-compact-source';const tag=document.createElement('span');tag.className='aqwc-source-tag';tag.dataset.kind=kind;tag.textContent=label;const body=document.createElement('div');body.className='aqwc-source-values';line.append(tag,body);
   let expanded=all;
   function fill(){
    body.replaceChildren();const limit=expanded?items.length:3;
    items.slice(0,limit).forEach((x,j)=>{
     if(j)body.append(document.createTextNode(' · '));
     const cmd=kind==='location'&&x.slug&&!/\b(shop|merge shop)\b/i.test(x.name)?x.join||(Object.hasOwn(verifiedMaps,x.slug)?verifiedMaps[x.slug]:null)||mapCache.get(x.slug):null;
     if(cmd){const map=document.createElement('a');map.href=origin+'/'+x.slug;map.textContent=x.name;body.append(map);joinControl(body,{...x,join:cmd},origin);return}
     const el=document.createElement(x.slug?'a':'span');el.textContent=x.name;if(x.slug)el.href=origin+'/'+x.slug+(x.hash||'');body.append(el);
     if(expanded&&kind==='location'&&x.slug&&!/\b(shop|merge shop)\b/i.test(x.name))joinControl(body,x,origin);
    });
    if(items.length>3&&!all){const more=document.createElement('button');more.type='button';more.className='aqwc-source-more';more.textContent=expanded?'Show less':'+'+(items.length-3)+' more';more.setAttribute('aria-expanded',String(expanded));more.addEventListener('click',e=>{if(e.isTrusted){expanded=!expanded;fill()}});body.append(more)}
   }
   fill();
   block.append(line);
  }
  if(data.merge)line('MERGE',data.merge.map(([name,qty])=>({name:name+' ×'+qty})),'merge');
  else if(data.alternatives)line('MERGE',[{name:data.alternatives+' alternative recipes'}],'merge');
  line('QUEST',s?.quests,'quest');line('DROP',s?.drops,'drop');
  line('SHOP',s?.shops,'shop');
  line('MAP',s?.locations?.filter(x=>!/\b(shop|merge shop)\b/i.test(x.name)),'location');
  if(all&&s?.locations?.some(x=>/\b(shop|merge shop)\b/i.test(x.name)))line('SHOP',s.locations.filter(x=>/\b(shop|merge shop)\b/i.test(x.name)),'shop');
  if(!block.children.length)return false;
  if(all){const link=document.createElement('a');link.href=origin+'/'+slug;link.textContent='Material Wiki ↗';link.className='aqwc-source-page';block.append(link);if(recipe?.incomplete||!recipe?.sources){const note=document.createElement('small');note.textContent='Source summary may be incomplete';block.append(note)}}
  row.append(block);return true;
 }
 function render(card,content,origin,onNextStep){
  const rootSlug=location.pathname.replace(/^\/|\/$/g,'');
  const {groups,incomplete}=reviewedRoutes(parse(content,origin),rootSlug);
  if(!groups.length&&!incomplete)return;
  const panel=document.createElement('details');panel.open=true;panel.className='aqwc-section aqwc-farming';panel.style.cssText='min-width:0;max-width:100%;';
  const heading=document.createElement('summary');heading.textContent='Farming Progress';panel.append(heading);card.append(panel);
  const note=text=>{const n=document.createElement('div');n.textContent=text;n.style.cssText=(globalThis.AQWCTheme?.recolor('font-size:11px;color:#b6cddd;margin:5px 0;font-weight:400')||'font-size:11px;color:#b6cddd;margin:5px 0;font-weight:400');return n};

  if(incomplete)panel.append(note('Some recipe rows could not be read; check the original Wiki requirements.'));
  if(!groups.length)return panel;
  const tree=document.createElement('div'),statusLine=note('Checking synced inventory…');statusLine.setAttribute('role','status');panel.append(tree,statusLine);
  const states=new Map(),cache=new Map(),names=new Set(groups.flat().map(x=>x.name));let matches=new Map(),busy=true,requests=0,activeOption=0;
  if(rootSlug==='blinding-light-of-destiny-axe')names.add('Get Your Blinding Light of Destiny');
  async function lookup(){
   const list=[...names];if(list.length>80)throw Error('Recipe material limit reached');
   const r=await chrome.runtime.sendMessage({type:'wiki-material-lookup',names:list});
   if(!r?.ok||!Array.isArray(r.matches)||r.matches.length!==list.length)throw Error('Inventory unavailable; refresh after syncing');
   matches=new Map(list.map((name,i)=>[name,r.matches[i]]));
   statusLine.textContent=r.syncedAt?'':'No inventory synced yet.';
  }
  function button(text){
   const b=document.createElement('button');b.type='button';b.textContent=text;b.disabled=busy;
   b.style.cssText=(globalThis.AQWCTheme?.recolor('font:600 11px system-ui;color:#a9ddff;background:#19334a;border:1px solid #466781;border-radius:4px;padding:2px 5px;cursor:pointer;white-space:nowrap')||'font:600 11px system-ui;color:#a9ddff;background:#19334a;border:1px solid #466781;border-radius:4px;padding:2px 5px;cursor:pointer;white-space:nowrap');return b
  }
  async function expand(n){
   if(busy)return;
   let s=states.get(n.path);
   if(s){s.open=!s.open;draw();return}
   s={open:true,choice:-1,groups:[],incomplete:false,error:'',sources:reviewedSources(n.slug),partial:true};states.set(n.path,s);
   busy=true;statusLine.textContent='Reading Wiki recipe…';draw();
   try{
    let recipe=cache.get(n.slug);
    if(!recipe||recipe.previewFailed){if(requests>=20)throw Error('Wiki recipe request limit reached');requests++;recipe=await loadRecipe(origin,n.slug);cache.set(n.slug,recipe)}
    s.sources=mergeSources(recipe.sources,reviewedSources(n.slug));s.partial=!!reviewedSources(n.slug)||recipe.incomplete;
    const next=new Set([...names,...recipe.groups.flat().map(x=>x.name)]);
    if(next.size>80)throw Error('Recipe material limit reached');
    for(const name of next)names.add(name);
    await lookup();
    s.groups=recipe.groups;s.incomplete=recipe.incomplete;s.choice=recipe.groups.length===1&&!recipe.incomplete?0:-1;
   }catch(err){s.error=String(err?.message||err);statusLine.textContent='Some nested requirements could not be loaded.'}
   finally{busy=false;draw()}
  }
  async function loadPreviews(group){
   if(busy)return;busy=true;statusLine.textContent='Reading material sources…';draw();
   try{for(const n of group.filter(n=>!cache.has(n.slug)&&!compactHints[n.slug]&&!reviewedSources(n.slug)).slice(0,6)){if(requests>=20)break;requests++;try{cache.set(n.slug,await loadRecipe(origin,n.slug))}catch{cache.set(n.slug,{groups:[],incomplete:true,previewFailed:true})}}}finally{busy=false;statusLine.textContent='';draw()}
  }
  function draw(){
   tree.replaceChildren();
   if(groups.length>1){const bar=document.createElement('div');bar.className='aqwc-recipe-tabs';groups.forEach((g,j)=>{const tab=button(recipeLabel(g,j,rootSlug));tab.setAttribute('aria-pressed',String(j===activeOption));tab.addEventListener('click',e=>{if(e.isTrusted&&!busy){activeOption=j;draw()}});bar.append(tab)});tree.append(bar)}
   groups.forEach((group,i)=>{if(i!==activeOption)return;
    if(rootSlug==='blinding-light-of-destiny-axe'&&i===0){
     const guide=document.createElement('div');guide.className='aqwc-source-guide';
     const a=document.createElement('a');a.href=origin+'/artix-s-quests';a.textContent='The Blinding Light of Destiny — Artix quests';
     const shop=document.createElement('a');shop.href=origin+'/blinding-light-of-destiny-shop';shop.textContent='Book of Lore reward shop';
     guide.append(a,note('Necropolis · Complete one Finding Fragments quest first. Turn in the six materials to receive Get Your Blinding Light of Destiny, then claim the axe in the reward shop.'),shop);
     joinControl(guide,{name:'Necropolis',slug:'necropolis',join:'necropolis'},origin);
     if(matches.get('Get Your Blinding Light of Destiny')?.state==='owned')guide.append(note('Unlock item found in synced inventory. You can claim the axe from the reward shop; no need to repeat this farm.'));
     tree.append(guide);
    }
    const p=plan(group,states,matches,rootSlug,i);
    if(!busy&&typeof onNextStep==='function'){
     const next=p.root.find(n=>Number.isFinite(n.missing)&&n.missing>0&&Number.isFinite(n.stock)&&matches.get(n.name)?.state!=='ambiguous'&&matches.get(n.name)?.state!=='unsynced');
     const unlock=rootSlug==='blinding-light-of-destiny-axe'&&matches.get('Get Your Blinding Light of Destiny')?.state==='owned';
     onNextStep(next&&!unlock?{name:next.name,slug:next.slug,missing:next.missing,source:compactData(next.slug,cache.get(next.slug)).sources||null}:null,{label:recipeLabel(group,i,rootSlug),incomplete:!!incomplete||!!p.limited,unlock:!!unlock,ingredients:p.root.map(n=>({name:n.name,slug:n.slug,target:n.target,missing:n.missing,source:compactData(n.slug,cache.get(n.slug)).sources||null}))});
    }
    if(!busy&&group.some(n=>!cache.has(n.slug)&&!Object.hasOwn(compactHints,n.slug)&&!reviewedSources(n.slug))&&requests<20){const load=button('Load material sources');load.className='aqwc-preview-load';load.addEventListener('click',e=>{if(e.isTrusted)loadPreviews(group)});tree.append(load)}
    if(!busy){const ready=p.root.filter(n=>n.missing===0).length,total=p.root.length,pct=total?Math.round(ready/total*100):0;const overview=document.createElement('div'),count=document.createElement('span'),percent=document.createElement('span');overview.className='aqwc-farm-overview';count.textContent=ready+' / '+total+' materials ready';percent.textContent=pct+'% ready';overview.append(count,percent);tree.append(overview);const track=document.createElement('div'),fill=document.createElement('div');track.className='aqwc-farm-track';fill.style.width=pct+'%';track.setAttribute('aria-label',ready+' of '+total+' direct ingredients ready');track.append(fill);tree.append(track)}
    const columns=document.createElement('div');columns.className='aqwc-column-labels';for(const label of ['Material','Acquisition / map','Progress']){const cell=document.createElement('span');cell.textContent=label;columns.append(cell)}tree.append(columns);
    function drawNode(n,container){
     const row=document.createElement('div');row.className='aqwc-material-row';
     const top=document.createElement('div');top.className='aqwc-material-top';
     const nameBox=document.createElement('div');nameBox.style.cssText='display:flex;align-items:center;gap:5px;min-width:0';
     const s=states.get(n.path);row.setAttribute('data-open',String(!!s?.open));
     if(n.missing>0&&n.depth<4&&!n.reason){const b=button(s?.open?'▾':'▸');b.setAttribute('aria-label',(s?.open?'Collapse ':'How to get ')+n.name);b.setAttribute('aria-expanded',String(!!s?.open));b.addEventListener('click',e=>{if(e.isTrusted)expand(n)});nameBox.append(b)}
     const a=document.createElement('a');a.href=origin+'/'+n.slug;a.textContent=n.name;a.style.cssText=(globalThis.AQWCTheme?.recolor('color:#a9ddff;text-decoration:underline;overflow-wrap:anywhere')||'color:#a9ddff;text-decoration:underline;overflow-wrap:anywhere');nameBox.append(a);
     const status=document.createElement('span');status.className='aqwc-material-progress';const done=n.missing===0,known=n.allocated!==null;
     const count=document.createElement('span');count.className='aqwc-progress-count';count.textContent=(known?(done?'✓ ':n.allocated?'◐ ':'✕ ')+n.allocated.toLocaleString():'?')+' / '+n.target.toLocaleString();
     status.style.color=done?'#90edb5':!known||n.allocated?'#ffdb93':'#ffc2a8';
     status.append(count);
     const detail=document.createElement('span');detail.className='aqwc-progress-detail';detail.textContent=!known?'Not synced':done?'Ready':n.missing.toLocaleString()+' missing';status.append(detail);
     if(known){const meter=document.createElement('span'),fill=document.createElement('span');meter.className='aqwc-progress-meter';fill.style.width=Math.max(0,Math.min(100,n.allocated/n.target*100))+'%';meter.setAttribute('aria-hidden','true');meter.append(fill);status.append(meter);status.title='Synced stock: '+n.stock.toLocaleString()+' · allocated to this requirement: '+n.allocated.toLocaleString()+(n.missing>0?' · '+n.missing.toLocaleString()+' remaining':'')}
     top.append(nameBox,status);row.append(top);
     container.append(row);
     const summaryShown=compactSummary(row,n.slug,cache.get(n.slug),origin);
     if(n.reason){const msg=note(n.reason);msg.className='aqwc-material-note';row.append(msg)}
     if(!s?.open||!n.missing)return;
     const nested=document.createElement('div');nested.className='aqwc-material-nested';row.append(nested);
     const recipe=cache.get(n.slug);const found=renderAcquisitionGuide(nested,n.slug,recipe||{sources:s.sources,groups:s.groups,incomplete:s.partial},origin);
     if(found&&summaryShown&&!s.error){const summary=row.querySelector(':scope > .aqwc-compact-sources');if(summary){summary.textContent='Acquisition details below';summary.style.color=(globalThis.AQWCTheme?.value('#b5c8d1','color')||'#b5c8d1');summary.style.fontSize='12px'}}
     if(s.error){nested.append(note('Wiki unavailable: '+s.error));const retry=button('Retry');retry.addEventListener('click',e=>{if(e.isTrusted&&!busy){states.delete(n.path);expand(n)}});nested.append(retry);return}
     if(busy&&!s.groups.length){nested.append(note('Loading…'));return}
     if(s.incomplete)nested.append(note('Some requirements could not be read. Verify the original Wiki page.'));
     if(!s.groups.length){if(!found)nested.append(note('No acquisition links recognized. Open the material page to check its sources.'));return}
     if(s.groups.length>1||s.incomplete){
      const select=document.createElement('select');select.setAttribute('aria-label','Recipe option for '+n.name);select.disabled=busy;select.style.cssText=(globalThis.AQWCTheme?.recolor('max-width:100%;background:#19334a;color:#e5f5ff;border:1px solid #466781;border-radius:4px;font:12px system-ui')||'max-width:100%;background:#19334a;color:#e5f5ff;border:1px solid #466781;border-radius:4px;font:12px system-ui');
      const first=document.createElement('option');first.value='-1';first.textContent='Choose merge option';select.append(first);
      s.groups.forEach((g,j)=>{const opt=document.createElement('option');opt.value=String(j);opt.textContent='Option '+(j+1)+' · '+g.map(x=>x.name+' ×'+x.target).join(', ');select.append(opt)});
      select.value=String(s.choice);select.addEventListener('change',e=>{if(!e.isTrusted||busy)return;const choice=Number(select.value);if(choice!==s.choice){for(const key of states.keys())if(key.startsWith(n.path+'.'))states.delete(key);s.choice=choice}draw()});nested.append(select);
     }
     if(s.choice>=0){const subLabel=note('Sub-recipe · Craft ×'+n.missing.toLocaleString()+' · '+n.children.filter(c=>c.missing===0).length+'/'+n.children.length+' ready');subLabel.className='aqwc-subrecipe-label';nested.append(subLabel);n.children.forEach(c=>drawNode(c,nested))}
    }
    p.root.forEach(n=>drawNode(n,tree));if(p.limited)tree.append(note('Recipe size limit reached; remaining requirements not evaluated.'));
   })
  }
  draw();lookup().catch(()=>{statusLine.textContent='Inventory unavailable. Sync in Companion and refresh this page.'}).finally(()=>{busy=false;draw()});return panel;
 }
 globalThis.AQWCWikiMaterials=Object.freeze({parse,parseRow,plan,render,parseSources,reviewedSources,mergeSources,renderSources,mapCommand,joinControl,recipeLabel,reviewedRoutes,sourceLink,compactData,acquisitionKind,parseAcquisitionLines,acquisitionLines,itemSummary,acquisitionGroups,monsterPreview,monsterImage,monsterImages,itemImages,itemPreview,previewCacheRequest});
})();
